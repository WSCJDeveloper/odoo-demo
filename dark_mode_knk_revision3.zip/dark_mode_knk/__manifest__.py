# -*- coding: utf-8 -*-
{
    'name': 'Dark mode',
    'version': '18.0.1.0',
    'summary': 'Dark Mode is an extension that helps you quickly turn the screen (browser) to dark in Odoo. This dark mode backend theme gives you a fully modified view with a full-screen display. It is a perfect choice for your Odoo Backend and an attractive theme for Odoo. | apps night mode | dark mode| night mode | enable dark mode | odoo night mode |',
    'description': """
       Dark Mode is an extension that helps you quickly turn the screen (browser) to dark in Odoo. This dark mode backend theme gives you a fully modified view with a full-screen display. It is a perfect choice for your Odoo Backend and an attractive theme for Odoo.
    """,
    'category': 'Website',
    'author': '',
    'license': 'OPL-1',
    'website': '',
    'depends': ['base', 'account', 'web', 'spreadsheet', 'sale'],
    'assets': {
        'web.assets_backend': [
            'dark_mode_knk/static/src/js/dark_mode_button.js',
            'dark_mode_knk/static/src/js/journal_dashboard_graph_override.js',
            'dark_mode_knk/static/src/xml/dark_mode_button.xml',
            'dark_mode_knk/static/src/scss/night_mode.scss',
        ],
    },
    'installable': True
}
