from odoo import fields, models, _
import logging

_logger = logging.getLogger(__name__)

class AccountJournal(models.Model):
    _inherit = "account.journal"

    def _get_bank_cash_graph_data(self):
        _logger.info("---------------------MY OVERRIDE IS BEING CALLED!----------------------------")
        result = super()._get_bank_cash_graph_data()
        
        # Update the color for each journal's graph data
        for journal_id, graph_data_list in result.items():
            for graph_data in graph_data_list:
                print(graph_data_list)
                graph_data['color'] = 'gray'  # Change to grey
        
        print(graph_data_list)
        return result