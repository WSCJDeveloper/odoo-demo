/** @odoo-module **/

import { JournalDashboardGraphField } from '@web/views/fields/journal_dashboard_graph/journal_dashboard_graph_field';
import { registry } from "@web/core/registry";
import { hexToRGBA } from "@web/core/colors/colors";

// First remove the existing registry entry
registry.category("fields").remove("dashboard_graph");

// Our modified version
class CustomJournalDashboardGraphField extends JournalDashboardGraphField {
    getColorBasedOnMode() {
        // Check if dark mode is active
        return document.body.classList.contains('knk_night_mode') ? '#808080' : null;
    }

    getLineChartConfig() {
        const config = super.getLineChartConfig();
        const greyColor = this.getColorBasedOnMode();
        if (greyColor) {
            config.data.datasets[0].borderColor = greyColor;
            config.data.datasets[0].backgroundColor = hexToRGBA(greyColor, 0.2);
        }
        return config;
    }

    getBarChartConfig() {
        const config = super.getBarChartConfig();
        const greyColor = this.getColorBasedOnMode();
        if (greyColor) {
            config.data.datasets[0].backgroundColor = config.data.datasets[0].backgroundColor.map(
                () => greyColor
            );
        }
        return config;
    }
}

// Add our custom version back to the registry
registry.category("fields").add("dashboard_graph", {
    component: CustomJournalDashboardGraphField,
    supportedTypes: ["text"],
    extractProps: ({ attrs }) => ({
        graphType: attrs.graph_type,
    }),
});


